

function Sobre() {
    return (
        <>
            
                <h2>Sobre</h2>
            
        </>
    )
}

export default Sobre
